HEPZIA website starter

Open index.html in a browser to preview it.
For a public URL, upload this folder to a hosting service such as Vercel or Netlify.
The email waitlist is currently a front-end demo and does not store submissions.
